import ImageDropzone from './ImageDropzone'

export default ImageDropzone
