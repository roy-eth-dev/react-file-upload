import LogoUploader from './LogoUploader'

export default LogoUploader
