import * as cloudStorage from './cloudStorage'

export default { cloudStorage }
