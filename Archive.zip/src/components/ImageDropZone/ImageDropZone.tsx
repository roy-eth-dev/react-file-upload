import React from 'react'
import styled from 'styled-components'
import { Colors } from '../../lib/style-guide'
import defaultImage from './default-image.svg'

type ImageDropZone = {
  value: string
  onChange: (url: string) => void
}

const ImageDropZone: FC<ImageDropZone> = ({ value, onChange, className }) => {
  return (
    <div className={className}>
      <img src={defaultImage} />
    </div>
  )
}

const StyledImageDropZone = styled(ImageDropZone)`
  border: 1px dashed ${Colors.DarkBlue};
  padding-top: 146px;
  background: ${Colors.BG3};
`

export default StyledImageDropZone
