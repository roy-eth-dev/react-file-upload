import ImageDropZone from './ImageDropZone'

export default ImageDropZone
